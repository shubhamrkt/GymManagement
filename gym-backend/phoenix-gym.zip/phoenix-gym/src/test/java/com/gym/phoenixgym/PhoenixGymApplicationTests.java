package com.gym.phoenixgym;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhoenixGymApplicationTests {

	@Test
	void contextLoads() {
	}

}
